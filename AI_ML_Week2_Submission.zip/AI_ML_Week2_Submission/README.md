# AI/ML Internship — Week 2 Submission

## Project
Data Preprocessing and Exploratory Data Analysis (EDA) using a synthetic student performance dataset.

## Files
- `Week2_Data_Preprocessing_EDA.ipynb` — notebook with code and explanations.
- `student_performance_raw.csv` — synthetic dataset with intentionally added missing values and duplicates.
- `student_performance_cleaned.csv` — cleaned dataset.
- `student_performance_encoded.csv` — cleaned dataset with one-hot encoded participation categories.
- `visualizations/` — four saved charts.
- `results_summary.txt` — summary of preprocessing and descriptive statistics.

## Work completed
1. Loaded and inspected the dataset.
2. Checked missing values and duplicates.
3. Removed duplicate rows.
4. Filled missing numeric values with median and categorical values with mode.
5. Identified potential outliers using IQR.
6. Encoded the categorical variable with one-hot encoding.
7. Standardized selected numerical features with `StandardScaler`.
8. Calculated correlations and created visualizations.
9. Saved cleaned and encoded datasets.

## Dataset source
Synthetic dataset generated for educational practice; it contains no real student records. State this clearly if asked about the source.

## How to run
Keep the notebook and CSV files in the same folder. Open the notebook in Jupyter or Google Colab and run cells from top to bottom. Required libraries: `pandas`, `numpy`, `matplotlib`, and `scikit-learn`.

## Before submitting
Run the notebook and review the results. Be ready to explain the code and findings. Check the form's requirements before uploading.
